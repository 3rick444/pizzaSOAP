package br.unipar.programacaoweb.daos;

import br.unipar.programacaoweb.models.Pedido;
import br.unipar.programacaoweb.utils.EntityManagerUtil;
import jakarta.persistence.EntityManager;

import java.util.List;

public class PedidoDAO {

    private EntityManager em = EntityManagerUtil.getEm();

    // Salvar um novo pedido
    public void salvar(Pedido pedido) {
        try {
            em.getTransaction().begin();
            em.persist(pedido);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    // Atualizar um pedido existente
    public void atualizar(Pedido pedido) {
        try {
            em.getTransaction().begin();
            em.merge(pedido);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    // Excluir um pedido pelo ID
    public boolean excluir(Integer id) {
        try {
            em.getTransaction().begin();
            Pedido pedido = em.find(Pedido.class, id);
            if (pedido != null) {
                em.remove(pedido);
                em.getTransaction().commit();
                return true;
            }
            return false;
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
            return false;
        }
    }

    // Buscar um pedido pelo ID
    public Pedido buscarPorId(Integer id) {
        try {
            return em.find(Pedido.class, id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Listar todos os pedidos
    public List<Pedido> buscarTodos() {
        try {
            return em.createQuery("FROM Pedido", Pedido.class).getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
