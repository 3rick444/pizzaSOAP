package br.unipar.programacaoweb.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Entity
@Getter
@Setter
public class Pedido implements Serializable {
    private static final long serialVersionUID = 1L;

   @Transient
    Itens_Pedido itens_pedido = new Itens_Pedido();

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    private String Observacoes;

    @Enumerated(EnumType.STRING)
    private StatusPedido status = StatusPedido.RECEBIDO;



    public Pedido(Cliente cliente, String Observacoes, StatusPedido status) {

        this.cliente = cliente;
        itens_pedido.calcularValorTotal();
        this.Observacoes = Observacoes;
        this.status = status;
    }

    public Pedido(int id, int clienteId, double valorTotal, String observacoes, String status) {
    }
}
