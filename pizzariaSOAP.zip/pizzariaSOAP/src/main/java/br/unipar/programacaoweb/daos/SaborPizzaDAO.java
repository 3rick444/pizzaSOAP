package br.unipar.programacaoweb.daos;

import br.unipar.programacaoweb.models.SaborPizza;
import br.unipar.programacaoweb.utils.EntityManagerUtil;
import jakarta.persistence.EntityManager;

import java.util.List;

public class SaborPizzaDAO {

    private EntityManager em = EntityManagerUtil.getEm();

    // Salvar um novo sabor de pizza
    public void salvar(SaborPizza saborPizza) {
        try {
            em.getTransaction().begin();
            em.persist(saborPizza);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    // Atualizar um sabor de pizza existente
    public void atualizar(SaborPizza saborPizza) {
        try {
            em.getTransaction().begin();
            em.merge(saborPizza);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    // Excluir um sabor de pizza pelo ID
    public boolean excluir(Integer id) {
        try {
            em.getTransaction().begin();
            SaborPizza saborPizza = em.find(SaborPizza.class, id);
            if (saborPizza != null) {
                em.remove(saborPizza);
                em.getTransaction().commit();
                return true;
            }
            return false;
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
            return false;
        }
    }

    // Buscar um sabor de pizza pelo ID
    public SaborPizza buscarPorId(Integer id) {
        try {
            return em.find(SaborPizza.class, id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Listar todos os sabores de pizza
    public List<SaborPizza> buscarTodos() {
        try {
            return em.createQuery("FROM SaborPizza", SaborPizza.class).getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Buscar sabores de pizza por IDs (utilizado na criação de pedidos)
    public List<SaborPizza> buscarPorIds(List<Integer> ids) {
        try {
            return em.createQuery("FROM SaborPizza WHERE id IN :ids", SaborPizza.class)
                    .setParameter("ids", ids)
                    .getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
