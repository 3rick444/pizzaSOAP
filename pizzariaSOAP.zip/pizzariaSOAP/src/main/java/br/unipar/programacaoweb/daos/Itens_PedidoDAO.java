package br.unipar.programacaoweb.daos;

import br.unipar.programacaoweb.models.Itens_Pedido;
import br.unipar.programacaoweb.models.Pedido;
import br.unipar.programacaoweb.utils.EntityManagerUtil;
import jakarta.persistence.EntityManager;

import java.util.List;

public class Itens_PedidoDAO {

    private EntityManager em = EntityManagerUtil.getEm();

    // Salvar um novo pedido
    public void salvar(Itens_Pedido ItPedido) {
        try {
            em.getTransaction().begin();
            em.persist(ItPedido);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    // Atualizar um pedido existente
    public void atualizar(Itens_Pedido ItPedido) {
        try {
            em.getTransaction().begin();
            em.merge(ItPedido);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    // Excluir um pedido pelo ID
    public boolean excluir(Integer id) {
        try {
            em.getTransaction().begin();
            Itens_Pedido ItPedido = em.find(Itens_Pedido.class, id);
            if (ItPedido != null) {
                em.remove(ItPedido);
                em.getTransaction().commit();
                return true;
            }
            return false;
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
            return false;
        }
    }

    // Buscar um pedido pelo ID
    public Itens_Pedido buscarPorId(Integer id) {
        try {
            return em.find(Itens_Pedido.class, id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Listar todos os pedidos
    public List<Itens_Pedido> buscarTodos() {
        try {
            return em.createQuery("FROM Itens_Pedido", Itens_Pedido.class).getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
