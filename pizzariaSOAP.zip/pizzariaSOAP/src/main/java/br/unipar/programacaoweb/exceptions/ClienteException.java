package br.unipar.programacaoweb.exceptions;

import jakarta.xml.ws.WebFault;

@WebFault(name = "UsuarioException")
public class ClienteException extends Exception {

    public ClienteException(String mensagem) {
        super(mensagem);
    }
}
