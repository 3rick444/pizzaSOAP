package br.unipar.programacaoweb.services;

import br.unipar.programacaoweb.exceptions.ClienteException;
import br.unipar.programacaoweb.models.*;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

import java.util.List;

@WebService
public interface ClienteSEI {

    @WebMethod
    String boasVindas(@WebParam(name = "nome")
                      String nome) throws ClienteException;

    @WebMethod
    String salvarNovoCliente(@WebParam(name = "nome") String nome,
                             @WebParam(name = "telefone") String telefone,
                             @WebParam(name = "cpf") String cpf,
                             @WebParam(name = "endereco") String endereco,
                             @WebParam(name = "data_nascimento") String data_nascimento)
            throws ClienteException;

    @WebMethod
    Cliente editarCliente(@WebParam Cliente cliente) throws ClienteException;

    @WebMethod
    List<Cliente> listarCliente() throws ClienteException;

    @WebMethod
    String excluirUsuario(@WebParam(name = "id") Integer id) throws ClienteException;

    //BORDA

    @WebMethod
    String inserirBorda(
            @WebParam(name = "id") int id,
            @WebParam(name = "sabor") String sabor
    )throws ClienteException;

    @WebMethod
    List<Borda> listarBordas()throws ClienteException;

    //ITENS PEDIDO

    @WebMethod
    String inserirItemPedido(
            @WebParam(name = "id") int id,
            @WebParam(name = "tamanho") String tamanho,
            @WebParam(name = "quantidade") int quantidade,
            @WebParam(name = "valor_unitario") double valor_unitario,
            @WebParam(name = "valor_total") double valor_total,
            @WebParam(name = "pizza_id") int pizza_id,
            @WebParam(name = "borda_id") int borda_id,
            @WebParam(name = "pedido_id") int pedido_id
    )throws ClienteException;

    @WebMethod
    List<Itens_Pedido> listarItensPedidos()throws ClienteException;

    //PEDIDO

    @WebMethod
    String inserirPedido(
            @WebParam(name = "id") int id,
            @WebParam(name = "cliente_id") int cliente_id,
            @WebParam(name = "valor_total") double valor_total,
            @WebParam(name = "observacoes") String observacoes,
            @WebParam(name = "status") String status
    );

    @WebMethod
    List<Pedido> listarPedidos()throws ClienteException;

    //PIZZA

    @WebMethod
    String inserirPizza(
            @WebParam(name = "id") int id,
            @WebParam(name = "sabor") String sabor
    )throws ClienteException;

    @WebMethod
    List<SaborPizza> listarPizzas()throws ClienteException;
}