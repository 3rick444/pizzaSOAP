package br.unipar.programacaoweb.tasks;

import br.unipar.programacaoweb.daos.PedidoDAO;
import br.unipar.programacaoweb.models.Pedido;
import br.unipar.programacaoweb.models.StatusPedido;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class AtualizadorStatusPedido {

    private PedidoDAO pedidoDAO;

    public AtualizadorStatusPedido() {
        this.pedidoDAO = new PedidoDAO();
    }

    public void iniciarAtualizacaoStatus() {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                atualizarStatusPedidos();
            }
        }, 0, 60000); // 60000 ms = 1 minuto
    }

    private void atualizarStatusPedidos() {
        List<Pedido> pedidos = pedidoDAO.buscarTodos();
        for (Pedido pedido : pedidos) {
            StatusPedido statusAtual = pedido.getStatus();
            StatusPedido proximoStatus = obterProximoStatus(statusAtual);

            if (proximoStatus != null) {
                pedido.setStatus(proximoStatus);
                pedidoDAO.atualizar(pedido); // Atualiza o pedido com o novo status
                System.out.println("Status do pedido " + pedido.getId() + " atualizado para: " + proximoStatus);
            }
        }
    }

    private StatusPedido obterProximoStatus(StatusPedido statusAtual) {
        switch (statusAtual) {
            case RECEBIDO:
                return StatusPedido.EM_PREPARO;
            case EM_PREPARO:
                return StatusPedido.PRONTO_PARA_RETIRADA;
            case PRONTO_PARA_RETIRADA:
                return StatusPedido.SAIU_PARA_ENTREGA;
            case SAIU_PARA_ENTREGA:
                return StatusPedido.ENTREGUE;
            default:
                return null; // Se o status for "ENTREGUE", não há próximo status
        }
    }
}
