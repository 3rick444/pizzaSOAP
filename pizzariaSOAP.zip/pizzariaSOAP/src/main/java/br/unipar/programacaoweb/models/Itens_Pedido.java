package br.unipar.programacaoweb.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Entity
@Getter
@Setter
public class Itens_Pedido implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String tamanho;
    private int quantidade;
    private double valor_unitario;
    private double valor_Total;

    @Enumerated(EnumType.STRING)
    private StatusPedido status = StatusPedido.RECEBIDO;

    @ManyToOne
    @JoinColumn(name = "pedido_id")
    private Pedido pedido;

    @ManyToMany
    @JoinColumn(name = "saborPizza_id")
    private List<SaborPizza> saboresPizza;

    @ManyToMany
    @JoinColumn(name = "borda_id")
    private List<Borda> bordas;

    public Itens_Pedido(int id, String tamanho, int quantidade, double valor_unitario, double valor_total, int pizza_id, int borda_id, int pedido_id) {
    }

    public Itens_Pedido(String tamanho, int quantidade, double valor_unitario, double valor_Total,
                        Pedido pedido, List<SaborPizza> saboresPizza, List<Borda> bordas) {

        this.tamanho = tamanho;
        this.quantidade = quantidade;
        this.valor_unitario = valor_unitario;
        calcularValorTotal();
        this.pedido = pedido;
        this.saboresPizza = saboresPizza;
        this.bordas = bordas;
    }

    public Itens_Pedido() {

    }

    public void calcularValorTotal() {
        double total = valor_unitario + quantidade;
        this.valor_Total = total;
    }
}
