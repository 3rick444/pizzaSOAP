package br.unipar.programacaoweb.services;


import br.unipar.programacaoweb.daos.BordaDAO;
import br.unipar.programacaoweb.daos.ClienteDAO;
import br.unipar.programacaoweb.exceptions.ClienteException;
import br.unipar.programacaoweb.models.*;
import jakarta.jws.WebService;

import java.util.ArrayList;
import java.util.List;


@WebService(endpointInterface =
        "br.unipar.programacaoweb.services.ClienteSEI")
public class ClienteSIB implements ClienteSEI {

    @Override
    public String boasVindas(String nome) {

        Cliente cliente = new Cliente();
        cliente.setNome(nome);

        if(usuarioExiste(cliente.getNome())) {
            return "Bem-vindo(a) de volta " + nome;
        } else {
            salvarNovoCliente(cliente);

            return "Bem-vindo(a) " + nome +
                    ", seu nome foi salvo em nossa base de dados!";
        }
    }

    @Override
    public String salvarNovoCliente(String nome, String telefone, String cpf, String endereco, String data_nascimento) {
        Cliente cliente = new Cliente(nome, telefone, cpf, endereco, data_nascimento);
        ClienteDAO dao = new ClienteDAO();
        dao.salvar(cliente);

        return "Usuário salvo com sucesso!";
    }

    @Override
    public Cliente editarCliente(Cliente cliente) throws ClienteException {
        ClienteDAO dao = new ClienteDAO();
        Cliente clienteEditado = dao.buscarPorId(cliente.getId());

        if(clienteEditado != null ) {
            clienteEditado.setNome(cliente.getNome());
            clienteEditado.setTelefone(cliente.getTelefone());
            clienteEditado.setCpf(cliente.getCpf());
            clienteEditado.setCpf(cliente.getEndereco());
            clienteEditado.setData_nascimento(cliente.getData_nascimento());

            ClienteDAO daoEditar = new ClienteDAO();
            daoEditar.atualizar(clienteEditado);
            return clienteEditado;
        }
        return null;
    }

    @Override
    public List<Cliente> listarCliente() {
        ClienteDAO dao = new ClienteDAO();
        return dao.buscarTodos();
    }

    @Override
    public String excluirUsuario(Integer id) throws ClienteException {
        ClienteDAO dao = new ClienteDAO();
        if(!dao.excluir(id)) {
            throw new ClienteException("Erro ao excluir usuário!");
        }

        return "Usuário excluído com sucesso!";
    }

    private boolean usuarioExiste(String nome) {
        ClienteDAO dao = new ClienteDAO();
        Cliente cliente = dao.buscarPorNome(nome);

        if(cliente == null) {
            return false;
        } else {
            return true;
        }

    }

    private void salvarNovoCliente(Cliente Cliente) {
        ClienteDAO dao = new ClienteDAO();
        dao.salvar(Cliente);
    }

    private List<Borda> listaBordas = new ArrayList<>();


    @Override
    public String inserirBorda(int id, String sabor) {
        Borda b = new Borda(id, sabor);
        listaBordas.add(b);
        return "Borda cadastrada com sucesso!";
    }

    @Override
    public List<Borda> listarBordas() {
        BordaDAO dao = new BordaDAO();
        return dao.buscarTodos();
    }

    private List<Itens_Pedido> listaItens = new ArrayList<>();

    @Override
    public String inserirItemPedido(int id, String tamanho, int quantidade, double valor_unitario,
                                    double valor_total, int pizza_id, int borda_id, int pedido_id) {
        Itens_Pedido item = new Itens_Pedido(id, tamanho, quantidade, valor_unitario, valor_total,
                pizza_id, borda_id, pedido_id);
        listaItens.add(item);
        return "Item do pedido cadastrado com sucesso!";
    }

    @Override
    public List<Itens_Pedido> listarItensPedidos() {
        return listaItens;
    }

    private List<Pedido> listaPedidos = new ArrayList<>();

    //PEDIDO

    @Override
    public String inserirPedido(int id, int cliente_id, double valor_total, String observacoes, String status) {
        Pedido pedido = new Pedido(id, cliente_id, valor_total, observacoes, status);
        listaPedidos.add(pedido);
        return "Pedido cadastrado com sucesso!";
    }

    @Override
    public List<Pedido> listarPedidos() {
        return listaPedidos;
    }

    private List<SaborPizza> listaPizzas = new ArrayList<>();

    @Override
    public String inserirPizza(int id, String sabor) {
        SaborPizza p = new SaborPizza(id, sabor);
        listaPizzas.add(p);
        return "Pizza cadastrada com sucesso!";
    }

    @Override
    public List<SaborPizza> listarPizzas() {
        return listaPizzas;
    }

}
