package br.unipar.programacaoweb.daos;

import br.unipar.programacaoweb.models.Cliente;
import br.unipar.programacaoweb.utils.EntityManagerUtil;
import jakarta.persistence.EntityManager;

import java.util.List;

public class ClienteDAO {

    private EntityManager em = EntityManagerUtil.getEm();

    // Salvar um novo cliente
    public void salvar(Cliente cliente) {
        try {
            em.getTransaction().begin();
            em.persist(cliente);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    // Atualizar um cliente existente
    public void atualizar(Cliente cliente) {
        try {
            em.getTransaction().begin();
            em.merge(cliente);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    // Excluir um cliente pelo ID
    public boolean excluir(Integer id) {
        try {
            em.getTransaction().begin();
            Cliente cliente = em.find(Cliente.class, id);
            if (cliente != null) {
                em.remove(cliente);
                em.getTransaction().commit();
                return true;
            }
            return false;
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
            return false;
        }
    }

    // Buscar um cliente pelo ID
    public Cliente buscarPorId(Integer id) {
        try {
            return em.find(Cliente.class, id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public Cliente buscarPorNome(String nome) {
        try {
            return em.createQuery("from Cliente where nome = :nome", Cliente.class)
                    .setParameter("nome", nome)
                    .getSingleResult();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            em.close();
        }
    }

    // Buscar um cliente pelo CPF
    public Cliente buscarPorCpf(String cpf) {
        try {
            return em.createQuery("FROM Cliente WHERE cpf = :cpf", Cliente.class)
                    .setParameter("cpf", cpf)
                    .getSingleResult();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Listar todos os clientes
    public List<Cliente> buscarTodos() {
        try {
            return em.createQuery("FROM Cliente", Cliente.class).getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
