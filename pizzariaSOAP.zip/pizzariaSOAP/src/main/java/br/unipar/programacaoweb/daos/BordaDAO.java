package br.unipar.programacaoweb.daos;

import br.unipar.programacaoweb.models.Borda;
import br.unipar.programacaoweb.utils.EntityManagerUtil;
import jakarta.persistence.EntityManager;

import java.util.List;

public class BordaDAO {

    private EntityManager em = EntityManagerUtil.getEm();

    // Salvar uma nova borda
    public void salvar(Borda borda) {
        try {
            em.getTransaction().begin();
            em.persist(borda);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    // Atualizar uma borda existente
    public void atualizar(Borda borda) {
        try {
            em.getTransaction().begin();
            em.merge(borda);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    // Excluir uma borda pelo ID
    public boolean excluir(Integer id) {
        try {
            em.getTransaction().begin();
            Borda borda = em.find(Borda.class, id);
            if (borda != null) {
                em.remove(borda);
                em.getTransaction().commit();
                return true;
            }
            return false;
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
            return false;
        }
    }

    // Buscar uma borda pelo ID
    public Borda buscarPorId(Integer id) {
        try {
            return em.find(Borda.class, id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Listar todas as bordas
    public List<Borda> buscarTodos() {
        try {
            return em.createQuery("FROM Borda", Borda.class).getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Buscar bordas por IDs (utilizado na criação de pedidos)
    public List<Borda> buscarPorIds(List<Integer> ids) {
        try {
            return em.createQuery("FROM Borda WHERE id IN :ids", Borda.class)
                    .setParameter("ids", ids)
                    .getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
