package br.unipar.programacaoweb.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Entity
@Getter
@Setter
public class SaborPizza implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String sabor;

    @ManyToMany(mappedBy = "saborPizza", cascade = CascadeType.ALL)
    private List<Pedido> pedidos;

    public SaborPizza() {
    }

    public SaborPizza(int id, String sabor) {
        this.sabor = sabor;
    }
}
